
package jsonPojo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "reference",
    "title",
    "date",
    "money",
    "description",
    "moreInfo",
    "finalMode",
    "my_join_field",
    "percentage"
})
public class Source implements Serializable
{

    @JsonProperty("reference")
    private String reference;
    @JsonProperty("title")
    private String title;
    @JsonProperty("date")
    private String date;
    @JsonProperty("money")
    private String money;
    @JsonProperty("description")
    private String description;
    @JsonProperty("moreInfo")
    private String moreInfo;
    @JsonProperty("finalMode")
    private String finalMode;
    @JsonProperty("my_join_field")
    private MyJoinField myJoinField;
    @JsonProperty("percentage")
    private String percentage;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 7258217971812331430L;

    @JsonProperty("reference")
    public String getReference() {
        return reference;
    }

    @JsonProperty("reference")
    public void setReference(String reference) {
        this.reference = reference;
    }

    @JsonProperty("title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(String title) {
        this.title = title;
    }

    @JsonProperty("date")
    public String getDate() {
        return date;
    }

    @JsonProperty("date")
    public void setDate(String date) {
        this.date = date;
    }

    @JsonProperty("money")
    public String getMoney() {
        return money;
    }

    @JsonProperty("money")
    public void setMoney(String money) {
        this.money = money;
    }

    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("moreInfo")
    public String getMoreInfo() {
        return moreInfo;
    }

    @JsonProperty("moreInfo")
    public void setMoreInfo(String moreInfo) {
        this.moreInfo = moreInfo;
    }

    @JsonProperty("finalMode")
    public String getFinalMode() {
        return finalMode;
    }

    @JsonProperty("finalMode")
    public void setFinalMode(String finalMode) {
        this.finalMode = finalMode;
    }

    @JsonProperty("my_join_field")
    public MyJoinField getMyJoinField() {
        return myJoinField;
    }

    @JsonProperty("my_join_field")
    public void setMyJoinField(MyJoinField myJoinField) {
        this.myJoinField = myJoinField;
    }

    @JsonProperty("percentage")
    public String getPercentage() {
        return percentage;
    }

    @JsonProperty("percentage")
    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
