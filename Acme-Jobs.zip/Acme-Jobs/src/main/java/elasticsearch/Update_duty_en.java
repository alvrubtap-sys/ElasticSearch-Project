
package elasticsearch;

public class Update_duty_en {

	public static void Update_duty(final String idDuty, final String idJob, final String title, final String description, final String percentage, final String variable) {
		Delete_duty_en.Delete_job(idDuty, variable);
		Post_duty_en.Post_duty(idDuty, idJob, title, description, percentage, variable);
	}
}
