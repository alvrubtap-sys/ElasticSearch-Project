
package elasticsearch;

public class Update_job_en {

	public static void Update_job(final String jobId, final String reference, final String title, final String date, final String money, final String description, final String moreInfo, final String finalMode, final String variable) {
		Delete_job_en.Delete_job(jobId, variable);
		Post_job_en.Post_job(jobId, reference, title, date, money, description, moreInfo, finalMode, variable);
	}
}
