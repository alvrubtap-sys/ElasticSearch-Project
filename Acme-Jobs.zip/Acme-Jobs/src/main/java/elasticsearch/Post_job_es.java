
package elasticsearch;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.io.IOUtils;

public class Post_job_es {

	public static void Post_job(final String jobId, final String reference, final String title, final String date, final String money, final String description, final String moreInfo, final String finalMode, final String variable) {

		System.out.println("Db port:" + variable);
		String query_url = "http://localhost:" + variable + "/job-es/_doc/" + jobId;
		String json = "{ \r\n" + "\r\n" + "\"reference\":\"" + reference + "\", \r\n" + "\r\n" + "\"title\":\"" + title + "\", \r\n" + "\r\n" + "\"Date\":\"" + date + "\", \r\n" + "\r\n" + "\"Money\":\"" + money + "\", \r\n" + "\r\n" + "\"Description\":\""
			+ description + "\", \r\n" + "\r\n" + "\"moreInfo\":\"" + moreInfo + "\", \r\n" + "\r\n" + "\"finalMode\":\"" + finalMode + "\", \r\n" + "\r\n" + "\"my_join_field\":{ \r\n" + "\r\n" + "\"name\":\"job\" \r\n" + "\r\n" + "} \r\n" + "\r\n" + "} ";
		try {
			URL url = new URL(query_url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5000);
			conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestMethod("POST");
			OutputStream os = conn.getOutputStream();
			os.write(json.getBytes("UTF-8"));
			os.close();
			// read the response
			InputStream in = new BufferedInputStream(conn.getInputStream());
			String result = IOUtils.toString(in, "UTF-8");
			System.out.println(result);

			in.close();
			conn.disconnect();
		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
