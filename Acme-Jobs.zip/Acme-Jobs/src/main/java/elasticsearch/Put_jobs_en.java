
package elasticsearch;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.io.IOUtils;

public class Put_jobs_en {

	public static void main(final String[] args) {
		Put_jobs_en.Put_job("9200");
	}
	public static void Put_job(final String variable) {
		System.out.println("Db port:" + variable);
		String query_url = "http://localhost:" + variable + "/job-en";
		String json = "{\r\n" + "    \"settings\": {\r\n" + "        \"number_of_shards\": 2,\r\n" + "        \"index\": {\r\n" + "            \"analysis\": {\r\n" + "                \"filter\": {\r\n" + "                    \"english_stop\": {\r\n"
			+ "                        \"type\": \"stop\",\r\n" + "                        \"stopwords\": \"_english_\"\r\n" + "                    },\r\n" + "                    \"english_keywords\": {\r\n"
			+ "                        \"type\": \"keyword_marker\",\r\n" + "                        \"keywords\": [\r\n" + "                            \"example\"\r\n" + "                        ]\r\n" + "                    },\r\n"
			+ "                    \"english_stemmer\": {\r\n" + "                        \"type\": \"stemmer\",\r\n" + "                        \"language\": \"english\"\r\n" + "                    },\r\n"
			+ "                    \"english_possessive_stemmer\": {\r\n" + "                        \"type\": \"stemmer\",\r\n" + "                        \"language\": \"possessive_english\"\r\n" + "                    },\r\n"
			+ "                    \"synonym\": {\r\n" + "                        \"type\": \"synonym\",\r\n" + "                        \"synonyms_path\":\"analysis/synonym-en.txt\"\r\n" + "                    },\r\n"
			+ "                    \"ngram_filter\": {\r\n" + "                        \"type\": \"ngram\",\r\n" + "                        \"min_gram\": 3,\r\n" + "                        \"max_gram\": 4\r\n" + "                    }\r\n"
			+ "                },\r\n" + "                \"analyzer\": {\r\n" + "                    \"rebuilt_english\": {\r\n" + "                        \"tokenizer\": \"standard\",\r\n" + "                        \"filter\": [\r\n"
			+ "                            \"english_possessive_stemmer\",\r\n" + "                            \"lowercase\",\r\n" + "                            \"synonym\",\r\n" + "                            \"ngram_filter\",\r\n"
			+ "                            \"english_stop\",\r\n" + "                            \"english_keywords\",\r\n" + "                            \"english_stemmer\"\r\n" + "                        ]\r\n" + "                    }\r\n"
			+ "                }\r\n" + "            }\r\n" + "        }\r\n" + "    },\r\n" + "    \"mappings\": {\r\n" + "        \"properties\": {\r\n" + "            \"my_join_fields\": {\r\n" + "                \"type\": \"join\",\r\n"
			+ "                \"relations\": {\r\n" + "                    \"job\": \"dutie\"\r\n" + "                }\r\n" + "            },\r\n" + "            \"date\": {\r\n" + "                \"type\": \"text\",\r\n"
			+ "                \"analyzer\": \"rebuilt_english\",\r\n" + "                \"search_analyzer\": \"rebuilt_english\"\r\n" + "            },\r\n" + "            \"description\": {\r\n" + "                \"type\": \"text\",\r\n"
			+ "                \"analyzer\": \"rebuilt_english\",\r\n" + "                \"search_analyzer\": \"rebuilt_english\"\r\n" + "            },\r\n" + "            \"finalMode\": {\r\n" + "                \"type\": \"text\",\r\n"
			+ "                \"analyzer\": \"rebuilt_english\",\r\n" + "                \"search_analyzer\": \"rebuilt_english\"\r\n" + "            },\r\n" + "            \"money\": {\r\n" + "                \"type\": \"text\",\r\n"
			+ "                \"analyzer\": \"rebuilt_english\",\r\n" + "                \"search_analyzer\": \"rebuilt_english\"\r\n" + "            },\r\n" + "            \"moreInfo\": {\r\n" + "                \"type\": \"text\",\r\n"
			+ "                \"analyzer\": \"rebuilt_english\",\r\n" + "                \"search_analyzer\": \"rebuilt_english\"\r\n" + "            },\r\n" + "            \"my_join_field\": {\r\n" + "                \"properties\": {\r\n"
			+ "                    \"name\": {\r\n" + "                        \"type\": \"text\",\r\n" + "                        \"analyzer\": \"rebuilt_english\",\r\n" + "                        \"search_analyzer\": \"rebuilt_english\"\r\n"
			+ "                    },\r\n" + "                    \"parent\": {\r\n" + "                        \"type\": \"text\",\r\n" + "                        \"analyzer\": \"rebuilt_english\",\r\n"
			+ "                        \"search_analyzer\": \"rebuilt_english\"\r\n" + "                    },\r\n" + "                    \"percentage\": {\r\n" + "                        \"type\": \"text\",\r\n"
			+ "                        \"analyzer\": \"rebuilt_english\",\r\n" + "                        \"search_analyzer\": \"rebuilt_english\"\r\n" + "                    },\r\n" + "                    \"reference\": {\r\n"
			+ "                        \"type\": \"text\",\r\n" + "                        \"analyzer\": \"rebuilt_english\",\r\n" + "                        \"search_analyzer\": \"rebuilt_english\"\r\n" + "                    },\r\n"
			+ "                    \"title\": {\r\n" + "                        \"type\": \"text\",\r\n" + "                        \"analyzer\": \"rebuilt_english\",\r\n" + "                        \"search_analyzer\": \"rebuilt_english\"\r\n"
			+ "                    }\r\n" + "                }\r\n" + "            }\r\n" + "        }\r\n" + "    }\r\n" + "}";
		try {
			URL url = new URL(query_url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5000);
			conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestMethod("PUT");
			OutputStream os = conn.getOutputStream();
			os.write(json.getBytes("UTF-8"));
			os.close();
			// read the response
			InputStream in = new BufferedInputStream(conn.getInputStream());
			String result = IOUtils.toString(in, "UTF-8");
			System.out.println(result);

			in.close();
			conn.disconnect();
		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
