
package elasticsearch;

public class Update_duty_es {

	public static void Update_duty(final String idDuty, final String idJob, final String title, final String description, final String percentage, final String variable) {
		Delete_duty_es.Delete_job(idDuty, variable);
		Post_duty_es.Post_duty(idDuty, idJob, title, description, percentage, variable);
	}
}
