
package elasticsearch;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.io.IOUtils;

public class Post_duty_es {

	public static void Post_duty(final String idDuty, final String idJob, final String title, final String description, final String percentage, final String variable) {
		System.out.println("Db port:" + variable);
		String query_url = "http://localhost:" + variable + "/job-es/_doc/" + idDuty;
		String json = "{  \r\n" + "\r\n" + "\"title\":\"" + title + "\",  \r\n" + "\r\n" + "\"description\":\"" + description + "\",  \r\n" + "\r\n" + "\"percentage\":\"" + percentage + "\",  \r\n" + "\r\n" + "\"my_join_field\":{  \r\n" + "\r\n"
			+ "\"name\":\"dutie\",  \r\n" + "\r\n" + "\"parent\":\"" + idJob + "\"  \r\n" + "\r\n" + "}  \r\n" + "\r\n" + "} ";
		try {
			URL url = new URL(query_url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5000);
			conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestMethod("POST");
			OutputStream os = conn.getOutputStream();
			os.write(json.getBytes("UTF-8"));
			os.close();
			// read the response
			InputStream in = new BufferedInputStream(conn.getInputStream());
			String result = IOUtils.toString(in, "UTF-8");
			System.out.println(result);

			in.close();
			conn.disconnect();
		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
