
package elasticsearch;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.io.IOUtils;

public class Sample_data_es {

	public static void main(final String[] args) {
		Sample_data_es.Sample_data_jobs("9200");
	}

	public static void Sample_data_jobs(final String variable) {
		Delete_jobs_es.Delete_jobs(variable);
		Put_jobs_es.Put_job(variable);

		System.out.println("Db port:" + variable);

		String query_url = "http://localhost:" + variable + "/_bulk?pretty";
		String json = "{\"create\":{\"_index\":\"job-es\",\"_type\":\"_doc\",\"_id\":\"111\"}} \r\n"
			+ "{\"reference\":\"EMP1-JOB6\",\"title\":\"Trabajo simple de ejemplo\",\"date\":\"2030/12/11 18:59\",\"money\":\"€ 15,000.98\",\"description\":\"Esto es un trabajo muy simple\",\"moreInfo\":\"http://www.example.com\",\"finalMode\":\"true\",\"my_join_field\":{\"name\":\"job\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-es\",\"_type\":\"_doc\",\"_id\":\"112\"}} \r\n" + "{\"title\":\"Tarea simple\",\"description\":\"Esto es un encargo simple\",\"percentage\":\"40\",\"my_join_field\":{\"name\":\"dutie\",\"parent\":\"111\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-es\",\"_type\":\"_doc\",\"_id\":\"113\"}}\r\n"
			+ "{\"reference\":\"EMP1-JOB7\",\"title\":\"Empleo en el desarrollo de aplicaciones\",\"date\":\"2030/12/11 19:59\",\"money\":\"€ 20,000.00\",\"description\":\"Desarrollo de apicaciones usando Java\",\"moreInfo\":\"http://www.example.com\",\"finalMode\":\"flse\",\"my_join_field\":{\"name\":\"job\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-es\",\"_type\":\"_doc\",\"_id\":\"114\"}} \r\n"
			+ "{\"title\":\"Encargo\",\"description\":\"Estudiar documentación de la API de java\",\"percentage\":\"100\",\"my_join_field\":{\"name\":\"dutie\",\"parent\":\"113\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-es\",\"_type\":\"_doc\",\"_id\":\"115\"}} \r\n"
			+ "{\"reference\":\"EMP1-JOB8\",\"title\":\"Oficio de manager\",\"date\":\"2019/11/11 20:59\",\"money\":\"€ 30,000.00\",\"description\":\"Puesto en equipo de desarrollo como manager\",\"moreInfo\":\"\",\"finalMode\":\"false\",\"my_join_field\":{\"name\":\"job\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-es\",\"_type\":\"_doc\",\"_id\":\"116\"}} \r\n" + "{\"title\":\"Tarea\",\"description\":\"Enviar curriculum\",\"percentage\":\"100\",\"my_join_field\":{\"name\":\"dutie\",\"parent\":\"115\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-es\",\"_type\":\"_doc\",\"_id\":\"117\"}} \r\n"
			+ "{\"reference\":\"EMP1-JOB9\",\"title\":\"Desarrollador en phyton\",\"date\":\"2030/12/11 21:59\",\"money\":\"€ 40,000.00\",\"description\":\"Se busca desarrollador con conocimientos en phyton\",\"moreInfo\":\"\",\"finalMode\":\"true\",\"my_join_field\":{\"name\":\"job\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-es\",\"_type\":\"_doc\",\"_id\":\"118\"}} \r\n"
			+ "{\"title\":\"Deber\",\"description\":\"Desarrollar proyecto simple en phyton\",\"percentage\":\"100\",\"my_join_field\":{\"name\":\"dutie\",\"parent\":\"117\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-es\",\"_type\":\"_doc\",\"_id\":\"119\"}} \r\n"
			+ "{\"reference\":\"EMP1-JOB0\",\"title\":\"Ocupación como developer en Java y Phyton\",\"date\":\"2030/12/11 22:59\",\"money\":\"€ 50,000.00\",\"description\":\"Se necesita desarrolladores co experiencia en phyton\",\"moreInfo\":\"http://www.example.com\",\"finalMode\":\"true\",\"my_join_field\":{\"name\":\"job\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-es\",\"_type\":\"_doc\",\"_id\":\"120\"}} \r\n"
			+ "{\"title\":\"Tarea 1\",\"description\":\"Demostrar que usted posee conocimientos en ambos lenguajes\",\"percentage\":\"100\",\"my_join_field\":{\"name\":\"dutie\",\"parent\":\"119\"}} \r\n" + "";
		try {
			URL url = new URL(query_url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5000);
			conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestMethod("POST");
			OutputStream os = conn.getOutputStream();
			os.write(json.getBytes("UTF-8"));
			os.close();
			// read the response
			InputStream in = new BufferedInputStream(conn.getInputStream());
			String result = IOUtils.toString(in, "UTF-8");
			System.out.println(result);

			in.close();
			conn.disconnect();
		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
