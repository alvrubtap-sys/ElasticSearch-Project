
package elasticsearch;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.io.IOUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import jsonPojo.ElasticResponse;

public class Get_jobs_en {

	public static ElasticResponse Get_jobs(final String searchBox, final String variable) {
		System.out.println("Db port:" + variable);
		String query_url = "http://localhost:" + variable + "/job-en/_doc/_search?pretty";
		//String json = "{\r\n" + "    \"query\": {\r\n" + "        \"multi_match\": {\r\n" + "            \"query\": \"" + searchBox + "\",\r\n" + "            \"fields\": [\r\n" + "                \"description\",\r\n" + "                \"title\"\r\n"
		//	+ "            ]\r\n" + "        }\r\n" + "    }\r\n" + "}";
		String json = String.format("{\r\n" + "    \"query\": {\r\n" + "        \"multi_match\": {\r\n" + "            \"query\": \"%s\",\r\n" + "            \"fields\": [\r\n" + "                \"description\",\r\n" + "                \"title\"\r\n"
			+ "            ]\r\n" + "        }\r\n" + "    }\r\n" + "}", searchBox);
		try {
			URL url = new URL(query_url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5000);
			conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestMethod("POST");
			OutputStream os = conn.getOutputStream();
			os.write(json.getBytes("UTF-8"));
			os.close();
			// read the response
			InputStream in = new BufferedInputStream(conn.getInputStream());
			String result = IOUtils.toString(in, "UTF-8");
			System.out.println(result);

			in.close();
			conn.disconnect();

			ObjectMapper mapper = new ObjectMapper();
			ElasticResponse elasticResponse = mapper.readValue(result, ElasticResponse.class);

			return elasticResponse;
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}

	}
}
