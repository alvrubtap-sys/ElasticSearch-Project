
package elasticsearch;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Component;

@Component
public class Sample_data_en {

	public static void main(final String[] args) {

		Sample_data_en.Sample_data_jobs("9200");
	}

	public static void Sample_data_jobs(final String variable) {

		Delete_jobs_en.Delete_jobs(variable);
		Put_jobs_en.Put_job(variable);

		System.out.println("Db port:" + variable);

		String query_url = "http://localhost:" + variable + "/_bulk?pretty";

		String json = "{\"create\":{\"_index\":\"job-en\",\"_type\":\"_doc\",\"_id\":\"100\"}} \r\n"
			+ "{\"reference\":\"EMP1-JOB1\",\"title\":\"Java Developer Job\",\"date\":\"2030/12/11 18:59\",\"money\":\"€ 15,000.98\",\"description\":\"Work on java based applications.\",\"moreInfo\":\"http://www.example.com\",\"finalMode\":\"true\",\"my_join_field\":{\"name\":\"job\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-en\",\"_type\":\"_doc\",\"_id\":\"101\"}} \r\n" + "{\"title\":\"Task 1\",\"description\":\"Study java API\",\"percentage\":\"40\",\"my_join_field\":{\"name\":\"dutie\",\"parent\":\"100\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-en\",\"_type\":\"_doc\",\"_id\":\"102\"}} \r\n"
			+ "{\"title\":\"Task 2\",\"description\":\"Develop new features for Acme-Jobs\",\"percentage\":\"60\",\"my_join_field\":{\"name\":\"dutie\",\"parent\":\"100\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-en\",\"_type\":\"_doc\",\"_id\":\"103\"}} \r\n"
			+ "{\"reference\":\"EMP2-JOB2\",\"title\":\"Work on web page development\",\"date\":\"2030/12/11 19:59\",\"money\":\"€ 20,000.00\",\"description\":\"Need developer with experience in HTML, CSS, jquery and ajax\",\"moreInfo\":\"http://www.example.com\",\"finalMode\":\"flse\",\"my_join_field\":{\"name\":\"job\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-en\",\"_type\":\"_doc\",\"_id\":\"104\"}} \r\n"
			+ "{\"title\":\"Duty 1\",\"description\":\"Create an example web page using your knowledge\",\"percentage\":\"100\",\"my_join_field\":{\"name\":\"dutie\",\"parent\":\"103\"}}\r\n"
			+ "{\"create\":{\"_index\":\"job-en\",\"_type\":\"_doc\",\"_id\":\"105\"}} \r\n"
			+ "{\"reference\":\"EMP4-JOB4\",\"title\":\"Team Manager\",\"date\":\"2019/11/11 20:59\",\"money\":\"€ 30,000.00\",\"description\":\"Vacancy on team manager for development of applications with Java and Phyton\",\"moreInfo\":\"\",\"finalMode\":\"false\",\"my_join_field\":{\"name\":\"job\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-en\",\"_type\":\"_doc\",\"_id\":\"106\"}} \r\n" + "{\"title\":\"Commision\",\"description\":\"Send curriculum\",\"percentage\":\"100\",\"my_join_field\":{\"name\":\"dutie\",\"parent\":\"105\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-en\",\"_type\":\"_doc\",\"_id\":\"107\"}} \r\n"
			+ "{\"reference\":\"EMP3-JOB3\",\"title\":\"Phyton developer\",\"date\":\"2030/12/11 21:59\",\"money\":\"€ 40,000.00\",\"description\":\"Position in Company 1, artifial intelligencce\",\"moreInfo\":\"\",\"finalMode\":\"true\",\"my_join_field\":{\"name\":\"job\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-en\",\"_type\":\"_doc\",\"_id\":\"108\"}} \r\n"
			+ "{\"title\":\"Assignment\",\"description\":\"Develop in phyton a simple IA\",\"percentage\":\"100\",\"my_join_field\":{\"name\":\"dutie\",\"parent\":\"107\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-en\",\"_type\":\"_doc\",\"_id\":\"109\"}} \r\n"
			+ "{\"reference\":\"EMP5-JOB5\",\"title\":\"Very simple Job\",\"date\":\"2030/12/11 22:59\",\"money\":\"€ 50,000.00\",\"description\":\"Here is a simple example of a Job\",\"moreInfo\":\"http://www.example.com\",\"finalMode\":\"true\",\"my_join_field\":{\"name\":\"job\"}} \r\n"
			+ "{\"create\":{\"_index\":\"job-en\",\"_type\":\"_doc\",\"_id\":\"110\"}} \r\n"
			+ "{\"title\":\"Responsability\",\"description\":\"Here is a simple responsability\",\"percentage\":\"100\",\"my_join_field\":{\"name\":\"dutie\",\"parent\":\"109\"}}\r\n";
		try {
			URL url = new URL(query_url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(5000);
			conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestMethod("POST");
			OutputStream os = conn.getOutputStream();
			os.write(json.getBytes("UTF-8"));
			os.close();
			// read the response
			InputStream in = new BufferedInputStream(conn.getInputStream());
			String result = IOUtils.toString(in, "UTF-8");
			System.out.println(result);

			in.close();
			conn.disconnect();
		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
