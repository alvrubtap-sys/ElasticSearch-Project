
package acme.features.employer.job;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import acme.entities.duties.Duty;
import acme.entities.jobs.Job;
import acme.entities.roles.Employer;
import acme.framework.components.Errors;
import acme.framework.components.Model;
import acme.framework.components.Request;
import acme.framework.entities.Principal;
import acme.framework.services.AbstractDeleteService;
import elasticsearch.Delete_duty_en;
import elasticsearch.Delete_duty_es;
import elasticsearch.Delete_job_en;
import elasticsearch.Delete_job_es;

@Service
public class EmployerJobDeleteService implements AbstractDeleteService<Employer, Job> {

	// Internal state ----------------------------------------------------------------
	@Value("${elastic}")
	private String					key;

	@Autowired
	private EmployerJobRepository	repository;


	// AbstractDeleteService<Employer, Job> interface --------------------------------

	@Override
	public boolean authorise(final Request<Job> request) {
		assert request != null;

		boolean result;
		int jobId;
		Job job;
		Employer employer;
		Principal principal;

		jobId = request.getModel().getInteger("id");
		job = this.repository.findOneJobById(jobId);
		employer = job.getEmployer();
		principal = request.getPrincipal();
		result = job.isFinalMode() || !job.isFinalMode() && employer.getUserAccount().getId() == principal.getAccountId();

		return result;
	}

	@Override
	public void bind(final Request<Job> request, final Job entity, final Errors errors) {
		assert request != null;
		assert entity != null;
		assert errors != null;

		request.bind(entity, errors);

	}

	@Override
	public void unbind(final Request<Job> request, final Job entity, final Model model) {
		assert request != null;
		assert entity != null;
		assert model != null;

		request.unbind(entity, model, "reference", "title", "deadline", "salary", "description", "moreInfo");

	}

	@Override
	public Job findOne(final Request<Job> request) {
		assert request != null;

		Job result;
		int id;
		id = request.getModel().getInteger("id");
		result = this.repository.findOneJobById(id);

		return result;
	}

	@Override
	public void validate(final Request<Job> request, final Job entity, final Errors errors) {
		assert request != null;
		assert entity != null;
		assert errors != null;

		boolean hasApplications;
		int countApplications;

		if (!errors.hasErrors()) {
			countApplications = this.repository.findCountApplicationByJobId(entity.getId());
			hasApplications = countApplications > 0;
			errors.state(request, !hasApplications, "*", "employer.job.error.hasApplications");
		}

	}

	@Override
	public void delete(final Request<Job> request, final Job entity) {
		assert request != null;
		assert entity != null;

		Collection<Duty> dutiesPerJob = this.repository.findAllDutiesByJobId(entity.getId());

		this.repository.deleteAll(dutiesPerJob);

		this.repository.delete(entity);
		String jobId = Integer.toString(entity.getId());

		if (request.getLocale().getLanguage().equals("en")) {
			Delete_job_en.Delete_job(jobId, this.key);
			dutiesPerJob.stream().forEach(d -> {
				Delete_duty_en.Delete_job(Integer.toString(d.getId()), this.key);
			});
		} else {
			Delete_job_es.Delete_job(jobId, this.key);
			dutiesPerJob.stream().forEach(d -> {
				Delete_duty_es.Delete_job(Integer.toString(d.getId()), this.key);
			});
		}
	}

}
