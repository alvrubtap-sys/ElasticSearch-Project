
package acme.features.worker.search;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import acme.entities.jobs.Job;
import acme.entities.roles.Worker;
import acme.framework.components.Model;
import acme.framework.components.Request;
import acme.framework.services.AbstractListService;
import elasticsearch.Get_jobs_en;
import elasticsearch.Get_jobs_es;
import jsonPojo.ElasticResponse;

@Service
public class WorkerSearchListService implements AbstractListService<Worker, Job> {

	@Value("${elastic}")
	private String			key;

	@Autowired
	WorkerSearchRepository	repository;


	@Override
	public boolean authorise(final Request<Job> request) {
		assert request != null;
		return true;
	}

	@Override
	public void unbind(final Request<Job> request, final Job entity, final Model model) {
		assert request != null;
		assert entity != null;
		assert model != null;

		request.unbind(entity, model, "reference", "description", "title");

	}

	@Override
	public Collection<Job> findMany(final Request<Job> request) {
		Collection<Job> j;
		j = new ArrayList<Job>();
		if (request.getModel().hasAttribute("search")) {
			if (request.getLocale().getLanguage().equals("es")) {
				ElasticResponse er;
				er = Get_jobs_es.Get_jobs(request.getModel().getString("search"), this.key);
				int i;

				for (i = 0; i < er.getHits().getHits().size(); i++) {
					Job e;
					if (er.getHits().getHits().get(i).getSource().getMyJoinField().getName().equals("dutie")) {
						e = this.repository.findOneJobById(Integer.parseInt(er.getHits().getHits().get(i).getSource().getMyJoinField().getParent()));
					} else {
						e = this.repository.findOneJobById(Integer.parseInt(er.getHits().getHits().get(i).getId()));
					}
					if (e.isFinalMode()) {
						j.add(e);
					}
				}

			} else {
				ElasticResponse er;
				er = Get_jobs_en.Get_jobs(request.getModel().getString("search"), this.key);

				int i;

				for (i = 0; i < er.getHits().getTotal().getValue(); i++) {
					Job e;
					if (er.getHits().getHits().get(i).getSource().getMyJoinField().getName().equals("dutie")) {
						e = this.repository.findOneJobById(Integer.parseInt(er.getHits().getHits().get(i).getSource().getMyJoinField().getParent()));
					} else {
						e = this.repository.findOneJobById(Integer.parseInt(er.getHits().getHits().get(i).getId()));
					}
					if (e.isFinalMode()) {
						j.add(e);
					}
				}

			}
		} else {
			if (request.getLocale().getLanguage().equals("es")) {
				ElasticResponse er;
				er = Get_jobs_es.Get_jobs("", this.key);
				int i;

				for (i = 0; i < er.getHits().getHits().size(); i++) {
					Job e;
					if (er.getHits().getHits().get(i).getSource().getMyJoinField().getName().equals("dutie")) {
						e = this.repository.findOneJobById(Integer.parseInt(er.getHits().getHits().get(i).getSource().getMyJoinField().getParent()));
					} else {
						e = this.repository.findOneJobById(Integer.parseInt(er.getHits().getHits().get(i).getId()));
					}
					if (e.isFinalMode()) {
						j.add(e);
					}
				}

			} else {
				ElasticResponse er;
				er = Get_jobs_en.Get_jobs("job", this.key);
				int i;

				for (i = 0; i < er.getHits().getTotal().getValue(); i++) {
					Job e;
					if (er.getHits().getHits().get(i).getSource().getMyJoinField().getName().equals("dutie")) {
						e = this.repository.findOneJobById(Integer.parseInt(er.getHits().getHits().get(i).getSource().getMyJoinField().getParent()));
					} else {
						e = this.repository.findOneJobById(Integer.parseInt(er.getHits().getHits().get(i).getId()));
					}
					if (e.isFinalMode()) {
						j.add(e);
					}
				}

			}
		}
		return j;
	}

}
