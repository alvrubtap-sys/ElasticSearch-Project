
package acme.features.authenticated.auditRecord;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import acme.entities.auditRecords.AuditRecord;
import acme.framework.components.Model;
import acme.framework.components.Request;
import acme.framework.entities.Authenticated;
import acme.framework.services.AbstractListService;

@Service
public class AuthenticatedAuditRecordListByJobService implements AbstractListService<Authenticated, AuditRecord> {

	// Internal state ------------------------------------------------------------------------

	@Autowired
	AuthenticatedAuditRecordRepository repository;


	// AbstractListService<Authenticated, AuditRecord> interface -----------------------------

	@Override
	public boolean authorise(final Request<AuditRecord> request) {
		assert request != null;
		return true;
	}

	@Override
	public void unbind(final Request<AuditRecord> request, final AuditRecord entity, final Model model) {
		assert request != null;
		assert entity != null;
		assert model != null;

		request.unbind(entity, model, "title", "creationMoment", "body");
		request.getModel().setAttribute("listJobId", entity.getJob().getId());
	}

	@Override
	public Collection<AuditRecord> findMany(final Request<AuditRecord> request) {
		assert request != null;

		Collection<AuditRecord> result;
		int jobId;

		jobId = request.getModel().getInteger("jobId");
		result = this.repository.findAllByJobId(jobId);

		return result;
	}

}
