
package acme.features.authenticated.auditRecord;

import java.util.Collection;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import acme.entities.auditRecords.AuditRecord;
import acme.framework.repositories.AbstractRepository;

@Repository
public interface AuthenticatedAuditRecordRepository extends AbstractRepository {

	@Query("select a from AuditRecord a where a.job.id = ?1 and a.status = true")
	Collection<AuditRecord> findAllByJobId(int jobId);

	@Query("select a from AuditRecord a where a.id = ?1")
	AuditRecord findOneById(int id);

}
